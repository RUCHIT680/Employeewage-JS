# Employee-Wage-JS
First Commit
